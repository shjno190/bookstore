﻿namespace BookstoreWeb.Controllers
{
    internal class dbQLyBanSachDataContext
    {
    }
}